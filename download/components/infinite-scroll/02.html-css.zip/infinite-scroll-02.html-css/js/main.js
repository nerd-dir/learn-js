/* eslint-env browser */
/* globals zlFetch */
// Start writing JavaScript here!
const rootendpoint = 'https://api.learnjavascript.today/letters'
