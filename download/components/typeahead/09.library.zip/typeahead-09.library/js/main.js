import Typeahead from './typeahead.js'

Typeahead(document.querySelector('.typeahead'))
