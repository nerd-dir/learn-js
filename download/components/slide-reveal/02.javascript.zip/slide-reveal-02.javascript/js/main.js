/* eslint-env browser */
// Start writing JavaScript here!
const callback = entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-visible')
    }
  })
}
const observer = new IntersectionObserver(callback)

const books = document.querySelectorAll('.book')
books.forEach(book => observer.observe(book))
