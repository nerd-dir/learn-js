export default function Tiny (options) {
  const element = typeof options.selector === 'string'
    ? document.querySelector(options.selector)
    : options.selector

  function _render () {
    element.innerHTML = options.template()
  }

  _render()
}
