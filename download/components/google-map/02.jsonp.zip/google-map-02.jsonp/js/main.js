/* globals google */
// ========================
// Functions
// ========================
/**
 * Fetch Google Maps API (JSONP).
 */
const fetchGoogleMapsApi = _ => {
  // Please change this to use your own API key!
  const apiKey = 'AIzaSyBOSppjMrbl5YQAUla6O9WNAL1w2zeWtLc'
  const script = document.createElement('script')
  script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&callback=initGoogleMaps`
  script.addEventListener('error', console.error)

  document.body.appendChild(script)
  document.body.removeChild(script)
}

/**
 * Initializes Google Map
 */
function initGoogleMaps () {
  const mapDiv = document.querySelector('#map')
  new google.maps.Map(mapDiv, {
    center: { lat: 1.3521, lng: 103.8198 },
    zoom: 13
  })
}

// ========================
// Execution
// ========================
fetchGoogleMapsApi()
