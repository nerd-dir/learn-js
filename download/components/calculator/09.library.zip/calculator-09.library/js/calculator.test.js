import Calculator from './calculator.js'

const calculator = Calculator()

function runTest (test) {
  calculator.pressKeys(...test.keys)
  console.log(calculator.displayValue)
  console.assert(calculator.displayValue === test.result, test.message)
  calculator.resetCalculator()
}

const tests = [
  // Test Number Keys
  {
    message: 'Number key',
    keys: ['2'],
    result: '2'
  }, {
    message: 'Number Number',
    keys: ['3', '5'],
    result: '35'
  }
]

tests.forEach(runTest)
