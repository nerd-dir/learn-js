import Tiny from './Tiny/tiny.js'
import HeroesList from './HeroesList/HeroesList.js'

Tiny({
  selector: document.body,

  components: {
    HeroesList
  },

  template () {
    return '<div tiny-component="HeroesList"></div>'
  }
})
