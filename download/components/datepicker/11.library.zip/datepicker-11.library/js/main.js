import Datepicker from './datepicker.js'

Datepicker({
  date: new Date(2019, 1, 13),
  inputElement: document.querySelector('input')
})
