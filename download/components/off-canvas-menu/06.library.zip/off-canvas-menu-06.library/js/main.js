import offCanvas from './off-canvas.js'

offCanvas({
  menu: document.querySelector('.nav'),
  menuButton: document.querySelector('.menu-button'),
  closeButton: document.querySelector('.close-button')
})
