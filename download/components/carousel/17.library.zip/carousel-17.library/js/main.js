import Carousel from './carousel.js'

const carousels = [...document.querySelectorAll('.carousel')]
carousels.forEach(carousel => {
  carousel.carousel = new Carousel(carousel)
})
